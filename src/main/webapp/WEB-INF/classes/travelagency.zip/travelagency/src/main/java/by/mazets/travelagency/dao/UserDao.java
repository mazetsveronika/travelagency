package by.mazets.travelagency.dao;

import by.mazets.travelagency.entity.User;
import by.mazets.travelagency.exception.TravelAgencyDaoException;

public interface UserDao extends EntityDao {

    User logIn(String login, String password) throws TravelAgencyDaoException;
    void setDiscount(int id, double discount) throws TravelAgencyDaoException;
    void setMoney(int id, double money) throws TravelAgencyDaoException;

}