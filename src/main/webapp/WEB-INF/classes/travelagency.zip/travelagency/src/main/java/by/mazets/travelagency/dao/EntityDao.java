package by.mazets.travelagency.dao;

import by.mazets.travelagency.entity.AbstractEntity;
import by.mazets.travelagency.exception.TravelAgencyDaoException;

import java.util.List;

public interface EntityDao {

    void create(AbstractEntity abstractEntity) throws TravelAgencyDaoException;
    void update (AbstractEntity abstractEntity) throws TravelAgencyDaoException;
    void delete (int id) throws TravelAgencyDaoException;
    AbstractEntity findById (int id) throws TravelAgencyDaoException;
    List<AbstractEntity> findAll () throws TravelAgencyDaoException;

}