package by.mazets.travelagency.service.impl;


import by.mazets.travelagency.dao.DaoFactory;
import by.mazets.travelagency.dao.UserDao;
import by.mazets.travelagency.entity.AbstractEntity;
import by.mazets.travelagency.entity.User;
import by.mazets.travelagency.exception.TravelAgencyDaoException;
import by.mazets.travelagency.exception.TravelAgencyServiceException;
import by.mazets.travelagency.service.UserService;
import by.mazets.travelagency.validator.UserValidator;
import by.mazets.travelagency.validator.impl.UserValidatorImpl;

import java.util.List;
import java.util.Optional;


public class UserServiceImpl implements UserService {

    private DaoFactory daoFactory = DaoFactory.getInstance();
    private UserDao userDao = daoFactory.getUserDao();

    public UserServiceImpl() {
    }
    private static final String INCORRECT_VALUE_PARAMETER = "incorrect";
    private static final String NUMBER_REMOVING_SYMBOLS_REGEX = "[+()-]";
    private static final String NUMBER_REPLACEMENT_REGEX = "";
    private static final String PICTURE_HEADER = "data:image/jpg;base64,";
    private static final String EMPTY_VALUE_PARAMETER = "";
    private static final UserService instance = new UserServiceImpl();


    public static UserService getInstance() {
        return instance;
    }

    @Override
    public Optional<User> findUser(String login, String password) throws TravelAgencyServiceException {
        private DaoFactory daoFactory = DaoFactory.getInstance();
        UserDao userDao = daoFactory.getUserDao(false);
        UserValidator validator = UserValidatorImpl.getInstance();
        try {
            if (validator.checkLogin(login) && validator.checkPassword(password)) {
                Optional<User> user = userDao.findUserByLogin(login);
                Optional<String> userPassword = userDao.findUserPassword(login);
                Optional<String> encodedPassword = PasswordEncoder.encode(password);
                if (user.isPresent() && userPassword.isPresent()
                        && encodedPassword.isPresent() && userPassword.get().equals(encodedPassword.get())) {
                    return user;
                }
            }
        } catch (TravelAgencyDaoException e) {
            logger.error("Error has occurred while searching for user with login \"{}\": {}", login, e);
            throw new TravelAgencyServiceException("Error has occurred while searching for user with login \"" + login + "\": ", e);
        } finally {
            userDao.closeConnection();
        }
        return Optional.empty();
    }



    @Override
    public void setDiscount(int id, double discount) throws TravelAgencyServiceException {
        if (id > 0 && discount >= 0) {
            try {
                userDao.setDiscount(id, discount);
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public void setMoney(int id, double money) throws TravelAgencyServiceException {
        if (id > 0 && money >= 0) {
            try {
                userDao.setMoney(id, money);
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public void create(AbstractEntity abstractEntity) throws TravelAgencyServiceException {
        if (abstractEntity != null) {
            try {
                userDao.create(abstractEntity);
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public void update(AbstractEntity abstractEntity) throws TravelAgencyServiceException {
        if (abstractEntity != null) {
            try {
                userDao.update(abstractEntity);
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public void delete(int id) throws TravelAgencyServiceException {
        if (id > 0) {
            try {
                userDao.delete(id);
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public AbstractEntity findById(int id) throws TravelAgencyServiceException {
        if (id > 0) {
            try {
                AbstractEntity user = userDao.findById(id);
                return user;
            } catch (TravelAgencyDaoException e) {
                throw new TravelAgencyServiceException(e);
            }
        } else {
            throw new TravelAgencyServiceException("Incorrect parameters.");
        }
    }

    @Override
    public List<AbstractEntity> findAll() throws TravelAgencyServiceException {
        try {
            List<AbstractEntity> users = userDao.findAll();
            return users;
        } catch (TravelAgencyDaoException e) {
            throw new TravelAgencyServiceException(e);
        }
    }

}