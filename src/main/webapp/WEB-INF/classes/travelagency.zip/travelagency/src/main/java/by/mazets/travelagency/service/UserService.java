package by.mazets.travelagency.service;

import by.mazets.travelagency.entity.User;
import by.mazets.travelagency.exception.TravelAgencyServiceException;



public interface UserService extends EntityService {
      User logIn(String login, String password) throws TravelAgencyServiceException;
    void setDiscount(int id, double discount) throws TravelAgencyServiceException;
    void setMoney(int id, double money) throws TravelAgencyServiceException;

}