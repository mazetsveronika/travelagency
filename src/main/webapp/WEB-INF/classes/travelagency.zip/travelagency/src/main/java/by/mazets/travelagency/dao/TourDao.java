package by.mazets.travelagency.dao;

import by.mazets.travelagency.exception.TravelAgencyDaoException;

public interface TourDao extends EntityDao {

    void setHotTour(int id, boolean isHot) throws TravelAgencyDaoException;

}