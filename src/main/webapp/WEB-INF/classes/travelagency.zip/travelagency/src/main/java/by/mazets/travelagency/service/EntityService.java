package by.mazets.travelagency.service;

import by.mazets.travelagency.entity.AbstractEntity;
import by.mazets.travelagency.exception.TravelAgencyDaoException;
import by.mazets.travelagency.exception.TravelAgencyServiceException;

import java.util.List;

public interface EntityService {

    void create(AbstractEntity abstractEntity) throws TravelAgencyDaoException, TravelAgencyServiceException;

    void update(AbstractEntity AbstractEntity) throws TravelAgencyDaoException, TravelAgencyServiceException;

    void delete(int id) throws TravelAgencyServiceException;

    AbstractEntity findById(int id) throws TravelAgencyServiceException;
    List<AbstractEntity> findAll () throws TravelAgencyServiceException;

}