package by.mazets.travelagency.command.impl;

import by.mazets.travelagency.command.Command;
import by.mazets.travelagency.command.PagePath;
import by.mazets.travelagency.command.Router;
import by.mazets.travelagency.entity.User;
import by.mazets.travelagency.exception.TravelAgencyServiceException;
import by.mazets.travelagency.service.ServiceFactory;
import by.mazets.travelagency.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ViewAccountCommand implements Command {

    private static final Logger logger = LogManager.getLogger();


    @Override
    public Router execute(HttpServletRequest request) {
        logger.debug("start ViewAccountCommand");
        Router page;
        HttpSession session = request.getSession(true);
        User currentUser = (User) request.getSession().getAttribute("user");
        int userID = currentUser.getId();

        logger.debug("ViewAccountCommand user: " + currentUser);

        ServiceFactory factory = ServiceFactory.getInstance();
        UserService userService = factory.getUserService();

        try {
            User user = (User) userService.findById(userID);
            if (user !=null) {
                request.setAttribute("user", user);
                session.setAttribute("username", user.getName());
                session.setAttribute("user_surname", user.getSurname());
                session.setAttribute("user_email", user.getEmail());
                session.setAttribute("user_money", user.getMoney());
                session.setAttribute("user_discount", user.getDiscount());
                session.setAttribute("user_login", user.getLogin());

                page = PagePath.ACCOUNT_PAGE;
            } else {
                logger.error("User not found.");
                session.setAttribute("error", "User not found.");
                page = PagePath.ERROR_PAGE;
            }

        } catch (TravelAgencyServiceException e) {
            logger.error("ViewAccountCommand error.", e);
            page = PagePath.ERROR_PAGE;
        }
        logger.debug("finish ViewAccountCommand");
        return page;
    }
}