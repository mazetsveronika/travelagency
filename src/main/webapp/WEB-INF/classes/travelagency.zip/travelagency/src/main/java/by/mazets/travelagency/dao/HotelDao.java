package by.mazets.travelagency.dao;

public interface HotelDao extends EntityDao {
}